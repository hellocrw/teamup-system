function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["widgets-widgets-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/routes/widgets/widgets/widgets.component.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/routes/widgets/widgets/widgets.component.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRoutesWidgetsWidgetsWidgetsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"alain-default__content-title\">\r\n  <h1>Widgets</h1>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card>\r\n      <div class=\"text-right text-grey\">\r\n        <i nz-icon nzType=\"pay-circle\" class=\"display-2\"></i>\r\n      </div>\r\n      <h3 class=\"h3\">99.999</h3>\r\n      <div class=\"text-grey\">Games played last month</div>\r\n      <nz-progress [nzStatus]=\"'active'\" [nzPercent]=\"60\" [nzShowInfo]=\"false\" [nzStrokeWidth]=\"5\"></nz-progress>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card>\r\n      <div class=\"text-right text-grey\">\r\n        <i nz-icon nzType=\"pie-chart\" class=\"display-2\"></i>\r\n      </div>\r\n      <h3 class=\"h3\">300</h3>\r\n      <div class=\"text-grey\">Coffee cups per day</div>\r\n      <nz-progress [nzStatus]=\"'success'\" [nzPercent]=\"30\" [nzShowInfo]=\"false\" [nzStrokeWidth]=\"5\"></nz-progress>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card>\r\n      <div class=\"text-right text-grey\">\r\n        <i nz-icon nzType=\"cloud\" class=\"display-2\"></i>\r\n      </div>\r\n      <h3 class=\"h3\">1000 Gb</h3>\r\n      <div class=\"text-grey\">Average Monthly Uploads</div>\r\n      <nz-progress [nzStatus]=\"'exception'\" [nzPercent]=\"10\" [nzShowInfo]=\"false\" [nzStrokeWidth]=\"5\"></nz-progress>\r\n    </nz-card>\r\n  </div>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card class=\"ant-card__body-nopadding\">\r\n      <div nz-row>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-right-1 border-bottom-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center text-red\">\r\n              <i nz-icon nzType=\"user\" class=\"display-2\"></i>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">10k</h4>\r\n              <div class=\"text-grey\">VISITORS</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-bottom-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center text-pink\">\r\n              <i nz-icon nzType=\"sound\" class=\"display-2\"></i>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">100%</h4>\r\n              <div class=\"text-grey\">VOLUME</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div nz-row>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-right-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center text-grey\">\r\n              <i nz-icon nzType=\"fork\" class=\"display-2\"></i>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">150</h4>\r\n              <div class=\"text-grey\">FORKS</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"12\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center text-green\">\r\n              <i nz-icon nzType=\"message\" class=\"display-2\"></i>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">10</h4>\r\n              <div class=\"text-grey\">MESSAGES</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n    <nz-card class=\"ant-card__body-nopadding\">\r\n      <div nz-row>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-right-1 border-bottom-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center\">\r\n              <g2-mini-bar\r\n                height=\"35\"\r\n                color=\"#999\"\r\n                borderWidth=\"3\"\r\n                [padding]=\"[36, 30, 30, 30]\"\r\n                [data]=\"smallData\"\r\n              ></g2-mini-bar>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">10k</h4>\r\n              <div class=\"text-grey\">VISITORS</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-bottom-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center\">\r\n              <g2-mini-bar\r\n                height=\"35\"\r\n                color=\"#999\"\r\n                borderWidth=\"3\"\r\n                [padding]=\"[36, 30, 30, 30]\"\r\n                [data]=\"smallData\"\r\n              ></g2-mini-bar>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">100%</h4>\r\n              <div class=\"text-grey\">VOLUME</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div nz-row>\r\n        <div nz-col [nzSpan]=\"12\" class=\"border-right-1\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center\">\r\n              <g2-mini-bar\r\n                height=\"35\"\r\n                color=\"#999\"\r\n                borderWidth=\"3\"\r\n                [padding]=\"[36, 30, 30, 30]\"\r\n                [data]=\"smallData\"\r\n              ></g2-mini-bar>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">150</h4>\r\n              <div class=\"text-grey\">FORKS</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"12\">\r\n          <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n            <div nz-col [nzSpan]=\"12\" class=\"text-center\">\r\n              <g2-mini-bar\r\n                height=\"35\"\r\n                color=\"#999\"\r\n                borderWidth=\"3\"\r\n                [padding]=\"[36, 30, 30, 30]\"\r\n                [data]=\"smallData\"\r\n              ></g2-mini-bar>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\" class=\"py-md\">\r\n              <h4 class=\"h4\">10</h4>\r\n              <div class=\"text-grey\">MESSAGES</div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card class=\"ant-card__body-nopadding\">\r\n      <div class=\"half-float half-float-md\">\r\n        <img src=\"./assets/tmp/img/half-float-bg-1.jpg\" />\r\n        <div class=\"half-float-bottom rounded-circle bg-grey-lighter\">\r\n          <img class=\"p-sm\" src=\"./assets/tmp/img/1.png\" />\r\n        </div>\r\n      </div>\r\n      <div class=\"text-center\">\r\n        <h3 class=\"h3\">cipchk</h3>\r\n        <div class=\"text-grey\">Lead director</div>\r\n        <div class=\"p-sm\">\r\n          Voluptate velit id mollit ex. Anim labore non dolore ad cupidatat aute reprehenderit ullamco culpa esse. Esse\r\n          exercitation laboris culpa ipsum pariatur mollit minim culpa magna.\r\n        </div>\r\n      </div>\r\n      <div class=\"text-center bg-grey-darker text-white\">\r\n        <div nz-row>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">400</h3>\r\n            <div>Photos</div>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">2000</h3>\r\n            <div>Likes</div>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">500</h3>\r\n            <div>Following</div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"8\">\r\n    <nz-card class=\"ant-card__body-nopadding\">\r\n      <div class=\"text-center bg-center py-lg text-white\" style=\"background-image: url('./assets/tmp/img/bg9.jpg');\">\r\n        <nz-avatar [nzSrc]=\"'./assets/tmp/img/1.png'\"></nz-avatar>\r\n        <h3 class=\"text-white\">cipchk</h3>\r\n        <div>\r\n          <i class=\"fa fa-github fa-fw\"></i>\r\n          @cipchk\r\n        </div>\r\n      </div>\r\n      <div class=\"text-center bg-grey-darker text-white\">\r\n        <div nz-row>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-md\">\r\n            <a (click)=\"msg.success('to twitter')\">\r\n              <i class=\"fa fa-twitter fa-2x\"></i>\r\n            </a>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-md\">\r\n            <a (click)=\"msg.success('to facebook')\">\r\n              <i class=\"fa fa-facebook fa-2x\"></i>\r\n            </a>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-md\">\r\n            <a (click)=\"msg.success('comment')\">\r\n              <i class=\"fa fa-comments fa-2x\"></i>\r\n            </a>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"py-sm bg-grey-lighter-h point\">\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <i class=\"fa fa-fw fa-clock-o text-grey\"></i>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"17\">Recent Activity</div>\r\n        <div nz-col [nzSpan]=\"3\">\r\n          <nz-tag [nzColor]=\"'blue'\">350</nz-tag>\r\n        </div>\r\n      </div>\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"py-sm bg-grey-lighter-h point\">\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <i class=\"fa fa-fw fa-user text-grey\"></i>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"17\">Following</div>\r\n        <div nz-col [nzSpan]=\"3\">\r\n          <nz-tag [nzColor]=\"'pink'\">150</nz-tag>\r\n        </div>\r\n      </div>\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"py-sm bg-grey-lighter-h point\">\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <i class=\"fa fa-fw fa-folder-open-o text-grey\"></i>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"17\">Photos</div>\r\n        <div nz-col [nzSpan]=\"3\">\r\n          <nz-tag [nzColor]=\"'green'\">100</nz-tag>\r\n        </div>\r\n      </div>\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"py-sm bg-grey-lighter-h point\">\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <i class=\"fa fa-fw fa-folder-open-o text-grey\"></i>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"17\">Article</div>\r\n        <div nz-col [nzSpan]=\"3\">\r\n          <nz-tag [nzColor]=\"'purple'\">100</nz-tag>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n</div>\r\n<div nz-row nzGutter=\"16\">\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-primary rounded-md\">\r\n      <div nz-col nzSpan=\"12\" class=\"p-md text-white\">\r\n        <div class=\"h2 mt0\">123,456</div>\r\n        <div class=\"text-nowrap\">Website Traffics</div>\r\n      </div>\r\n      <div nz-col nzSpan=\"12\">\r\n        <g2-mini-bar height=\"35\" color=\"#fff\" borderWidth=\"3\" [padding]=\"[36, 30, 30, 30]\" [data]=\"data\"></g2-mini-bar>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-success rounded-md\">\r\n      <div nz-col nzSpan=\"12\" class=\"p-md text-white\">\r\n        <div class=\"h2 mt0\">234,567K</div>\r\n        <div class=\"text-nowrap\">Website Impressions</div>\r\n      </div>\r\n      <div nz-col nzSpan=\"12\">\r\n        <g2-mini-bar height=\"35\" color=\"#fff\" borderWidth=\"3\" [padding]=\"[36, 30, 30, 30]\" [data]=\"data\"></g2-mini-bar>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-orange rounded-md\">\r\n      <div nz-col nzSpan=\"12\" class=\"p-md text-white\">\r\n        <div class=\"h2 mt0\">$458,778</div>\r\n        <div class=\"text-nowrap\">Total Sales</div>\r\n      </div>\r\n      <div nz-col nzSpan=\"12\">\r\n        <g2-mini-bar height=\"35\" color=\"#fff\" borderWidth=\"3\" [padding]=\"[36, 30, 30, 30]\" [data]=\"data\"></g2-mini-bar>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-magenta rounded-md\">\r\n      <div nz-col nzSpan=\"12\" class=\"p-md text-white\">\r\n        <div class=\"h2 mt0\">456</div>\r\n        <div class=\"text-nowrap\">Support Tickets</div>\r\n      </div>\r\n      <div nz-col nzSpan=\"12\">\r\n        <g2-mini-bar height=\"35\" color=\"#fff\" borderWidth=\"3\" [padding]=\"[36, 30, 30, 30]\" [data]=\"data\"></g2-mini-bar>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row nzGutter=\"16\">\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-primary text-center rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-white\">\r\n        <i nz-icon nzType=\"user\" class=\"display-2\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-white py-md\">\r\n        <h3 class=\"h3 mb0\">10k</h3>\r\n        <div class=\"text-grey-dark\">VISITORS</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-magenta text-center rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-white\">\r\n        <i nz-icon nzType=\"sound\" class=\"display-2\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-white py-md\">\r\n        <h3 class=\"h3 mb0\">100%</h3>\r\n        <div class=\"text-grey-dark\">VOLUME</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-grey-darker text-center rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-white\">\r\n        <i nz-icon nzType=\"fork\" class=\"display-2\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-white py-md\">\r\n        <h3 class=\"h3 mb0\">150</h3>\r\n        <div class=\"text-grey-dark\">FORKS</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-green text-center rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-white\">\r\n        <i nz-icon nzType=\"message\" class=\"display-2\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-white py-md\">\r\n        <h3 class=\"h3 mb0\">10</h3>\r\n        <div class=\"text-grey-dark\">NEW MESSAGES</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-green-dark text-white rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-center\">\r\n        <i nz-icon nzType=\"share-alt\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-green-light p-md\">\r\n        <h2 class=\"h2 text-white mb0\">150</h2>\r\n        <div class=\"text-lg text-uppercase\">New connections</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-red-dark text-white rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-center\">\r\n        <i nz-icon nzType=\"star\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-red-light p-md\">\r\n        <h2 class=\"h2 text-white mb0\">7000</h2>\r\n        <div class=\"text-lg text-uppercase\">RATINGS RECEIVED</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-warning-dark text-white rounded-md\">\r\n      <div nz-col nzSpan=\"8\" class=\"p-md text-center\">\r\n        <i nz-icon nzType=\"trophy\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"16\" class=\"bg-warning-light p-md\">\r\n        <h2 class=\"h2 text-white mb0\">15</h2>\r\n        <div class=\"text-lg text-uppercase\">ACHIEVEMENTS</div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row nzGutter=\"16\">\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-green text-white text-center rounded-md\">\r\n      <div nz-col nzSpan=\"10\" class=\"p-md\">\r\n        <i nz-icon nzType=\"book\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"14\" class=\"py-md\">\r\n        <h1 class=\"text-white mb0\">120</h1>\r\n        <div>New Tasks!</div>\r\n      </div>\r\n      <a nz-col nzSpan=\"24\" (click)=\"msg.info('view')\" class=\"d-block p-sm bg-grey-darker text-white\">\r\n        <div class=\"float-left\">View Details</div>\r\n        <div class=\"float-right\">\r\n          <i class=\"fa fa-chevron-circle-right\"></i>\r\n        </div>\r\n      </a>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-primary text-white text-center rounded-md\">\r\n      <div nz-col nzSpan=\"10\" class=\"p-md\">\r\n        <i nz-icon nzType=\"message\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"14\" class=\"py-md\">\r\n        <h1 class=\"text-white mb0\">36</h1>\r\n        <div>New Comments!</div>\r\n      </div>\r\n      <a nz-col nzSpan=\"24\" (click)=\"msg.info('view')\" class=\"d-block p-sm bg-grey-darker text-white\">\r\n        <div class=\"float-left\">View Details</div>\r\n        <div class=\"float-right\">\r\n          <i class=\"fa fa-chevron-circle-right\"></i>\r\n        </div>\r\n      </a>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-warning text-white text-center rounded-md\">\r\n      <div nz-col nzSpan=\"10\" class=\"p-md\">\r\n        <i nz-icon nzType=\"shopping-cart\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"14\" class=\"py-md\">\r\n        <h1 class=\"text-white mb0\">110</h1>\r\n        <div>New Orders!</div>\r\n      </div>\r\n      <a nz-col nzSpan=\"24\" (click)=\"msg.info('view')\" class=\"d-block p-sm bg-grey-darker text-white\">\r\n        <div class=\"float-left\">View Details</div>\r\n        <div class=\"float-right\">\r\n          <i class=\"fa fa-chevron-circle-right\"></i>\r\n        </div>\r\n      </a>\r\n    </div>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"6\" class=\"mb-md\">\r\n    <div nz-row nzType=\"flex\" nzAlign=\"middle\" class=\"bg-red text-white text-center rounded-md\">\r\n      <div nz-col nzSpan=\"10\" class=\"p-md\">\r\n        <i nz-icon nzType=\"customer-service\" class=\"display-1\"></i>\r\n      </div>\r\n      <div nz-col nzSpan=\"14\" class=\"py-md\">\r\n        <h1 class=\"text-white mb0\">19</h1>\r\n        <div>Support Tickets!</div>\r\n      </div>\r\n      <a nz-col nzSpan=\"24\" (click)=\"msg.info('view')\" class=\"d-block p-sm bg-grey-darker text-white\">\r\n        <div class=\"float-left\">View Details</div>\r\n        <div class=\"float-right\">\r\n          <i class=\"fa fa-chevron-circle-right\"></i>\r\n        </div>\r\n      </a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"12\" [nzMd]=\"8\">\r\n    <nz-card nzTitle=\"服务\" [nzExtra]=\"extra\">\r\n      <ng-template #extra>\r\n        <a (click)=\"msg.info('更多服务')\">更多服务</a>\r\n      </ng-template>\r\n      <div class=\"pb-md\">\r\n        <i nz-icon nzType=\"check-circle\" class=\"text-green\"></i> 已开通 16 个\r\n        <i nz-icon nzType=\"check-circle\" class=\"pl-md\"></i> 未开通 4 个\r\n      </div>\r\n      <nz-carousel style=\"overflow: initial;\">\r\n        <div nz-carousel-content>\r\n          <div nz-row [nzGutter]=\"24\" class=\"mb-md\">\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"laptop\" class=\"display-2 text-blue\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">服务注册中心</h4>\r\n                  <div class=\"text-grey\">Register Server</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"rocket\" class=\"display-2 text-red\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">可靠消息</h4>\r\n                  <div class=\"text-grey\">Msg Broker</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div nz-row [nzGutter]=\"24\">\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"usb\" class=\"display-2 text-purple\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">分布式资源管理</h4>\r\n                  <div class=\"text-grey\">DRM</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"fork\" class=\"display-2 text-pink\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">分布式数据管理</h4>\r\n                  <div class=\"text-grey\">ZDC</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div nz-carousel-content>\r\n          <div nz-row [nzGutter]=\"24\" class=\"mb-md\">\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"laptop\" class=\"display-2 text-blue\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">服务注册中心</h4>\r\n                  <div class=\"text-grey\">Register Server</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"rocket\" class=\"display-2 text-red\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue mb0\">可靠消息</h4>\r\n                  <div class=\"text-grey\">Msg Broker</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div nz-row [nzGutter]=\"24\">\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"usb\" class=\"display-2 text-purple\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue\">分布式资源管理</h4>\r\n                  <div class=\"text-grey\">DRM</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div nz-col [nzSpan]=\"12\">\r\n              <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n                <div nz-col [nzSpan]=\"8\">\r\n                  <i nz-icon nzType=\"fork\" class=\"display-2 text-pink\"></i>\r\n                </div>\r\n                <div nz-col [nzSpan]=\"16\">\r\n                  <h4 class=\"fs-md text-blue\">分布式数据管理</h4>\r\n                  <div class=\"text-grey\">ZDC</div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </nz-carousel>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"12\" [nzMd]=\"8\">\r\n    <nz-card nzTitle=\"开发服务器\">\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\">\r\n        <div nz-col [nzSpan]=\"4\">\r\n          <i nz-icon nzType=\"database\" class=\"display-1\"></i>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"15\">\r\n          <h3 class=\"font-weight-bold mb0\">暂无服务器</h3>\r\n          <div class=\"pt-sm text-grey-dark d-flex align-items-center\">\r\n            <nz-badge [nzStatus]=\"'error'\"></nz-badge>\r\n            服务器申请失败\r\n          </div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"5\" class=\"text-right\">\r\n          <button nz-button (click)=\"msg.info('Apply')\" [nzType]=\"'default'\">\r\n            <span>申请</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzSm]=\"12\" [nzMd]=\"8\">\r\n    <nz-card nzTitle=\"华东 1\" class=\"ant-card__body-nopadding\" [nzExtra]=\"extra\">\r\n      <ng-template #extra>\r\n        <i nz-tooltip nzTooltipTitle=\"购买实例\" nz-icon nzType=\"shopping-cart\" class=\"display-3\"></i>\r\n      </ng-template>\r\n      <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" [nzGutter]=\"8\">\r\n        <div nz-col [nzSpan]=\"12\" class=\"text-center\">\r\n          云服务器\r\n          <strong class=\"display-1 text-blur\">12</strong>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"12\" class=\"my-md pl-md border-left-1\">\r\n          <div class=\"pb-sm\">\r\n            <nz-badge [nzStatus]=\"'success'\"></nz-badge>\r\n            运行中\r\n            <strong class=\"text-green\">2</strong>\r\n          </div>\r\n          <div class=\"pb-sm\">\r\n            <nz-badge [nzStatus]=\"'default'\"></nz-badge>\r\n            近期创建\r\n            <strong class=\"text-grey\">0</strong>\r\n          </div>\r\n          <div class=\"pb-sm\">\r\n            <nz-badge [nzStatus]=\"'error'\"></nz-badge>\r\n            即将过期\r\n            <strong class=\"text-red\">0</strong>\r\n          </div>\r\n          <div class=\"pb-sm\">\r\n            <nz-badge [nzStatus]=\"'error'\"></nz-badge>\r\n            已过期\r\n            <strong class=\"text-red\">1</strong>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div nz-row class=\"text-center border-top-1\">\r\n        <div nz-col [nzSpan]=\"8\" class=\"bg-grey-lighter-h py-sm point\">\r\n          磁盘\r\n          <strong class=\"text-blue\">18</strong>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"8\" class=\"bg-grey-lighter-h py-sm point\">\r\n          快照\r\n          <strong>0</strong>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"8\" class=\"bg-grey-lighter-h py-sm point\">\r\n          镜像\r\n          <strong class=\"text-blue\">2</strong>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col [nzXs]=\"24\" [nzMd]=\"12\" class=\"mb-md\">\r\n    <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"bg-white py-md rounded-md\">\r\n      <div nz-col [nzSpan]=\"3\" class=\"text-center\">\r\n        <span class=\"ant-avatar ant-avatar-lg ant-avatar-circle ant-avatar-icon bg-primary\">\r\n          <i nz-icon nzType=\"dashboard\"></i>\r\n        </span>\r\n      </div>\r\n      <div nz-col [nzSpan]=\"6\">\r\n        <strong class=\"display-2\">10</strong> 个\r\n        <div class=\"text-grey\">运行测压任务</div>\r\n      </div>\r\n      <div nz-col [nzSpan]=\"5\" class=\"d-flex align-items-center\">\r\n        <nz-badge [nzStatus]=\"'success'\"></nz-badge>\r\n        已完成\r\n        <span class=\"display-3 text-grey-dark pl-sm\">3</span>\r\n      </div>\r\n      <div nz-col [nzSpan]=\"5\" class=\"d-flex align-items-center\">\r\n        <nz-badge [nzStatus]=\"'processing'\"></nz-badge>\r\n        正在进行\r\n        <span class=\"display-3 text-grey-dark pl-sm\">5</span>\r\n      </div>\r\n      <div nz-col [nzSpan]=\"5\" class=\"d-flex align-items-center\">\r\n        <nz-badge [nzStatus]=\"'error'\"></nz-badge>\r\n        已失败\r\n        <span class=\"display-3 text-grey-dark pl-sm\">2</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div nz-col [nzXs]=\"24\" [nzMd]=\"12\" class=\"mb-md\">\r\n    <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"bg-white rounded-md border p-md\">\r\n      <div nz-col [nzSpan]=\"16\">\r\n        你觉得这篇文章如何：\r\n      </div>\r\n      <div nz-col [nzSpan]=\"8\" class=\"text-right\">\r\n        <span\r\n          nz-popconfirm\r\n          [(nzVisible)]=\"like\"\r\n          [nzPopconfirmPlacement]=\"'top'\"\r\n          [nzPopconfirmTitle]=\"'喜欢就开启此内容提醒吧！'\"\r\n          [nzOkText]=\"'立即开启'\"\r\n          [nzCancelText]=\"'下次再说'\"\r\n          (nzOnConfirm)=\"msg.success('开启提醒')\"\r\n          (nzOnCancel)=\"msg.error('取消提醒')\"\r\n          style=\"display:inline-block; padding-top:15px;\"\r\n        ></span>\r\n        <span class=\"pr-lg\">\r\n          <i nz-icon nzType=\"like\" class=\"display-3 point\" [class.text-primary]=\"like\" (click)=\"like = !like\"></i> 赞\r\n        </span>\r\n        <i\r\n          nz-icon\r\n          nzType=\"dislike\"\r\n          class=\"display-3 point\"\r\n          [class.text-primary]=\"dislike\"\r\n          (click)=\"dislike = !dislike\"\r\n        ></i>\r\n        踩\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row [nzGutter]=\"16\">\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <nz-card class=\"ant-card__body-nopadding bg-green rounded-md\">\r\n      <div class=\"p-md\">\r\n        <div class=\"h5 pb-sm text-white\">Received all time</div>\r\n        <g2-mini-area color=\"#fff\" height=\"46\" [data]=\"data\"></g2-mini-area>\r\n      </div>\r\n      <div class=\"text-center bg-grey-darker text-white\">\r\n        <div nz-row>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">400</h3>\r\n            <div>Photos</div>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">2000</h3>\r\n            <div>Likes</div>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"8\" class=\"py-sm\">\r\n            <h3 class=\"text-white mb0\">500</h3>\r\n            <div>Following</div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <nz-card class=\"ant-card__body-nopadding bg-green rounded-md\">\r\n      <div class=\"p-md\">\r\n        <div class=\"h5 pb-sm text-white\">Monthly incomes</div>\r\n        <g2-mini-area color=\"#fff\" height=\"46\" [data]=\"data\"></g2-mini-area>\r\n      </div>\r\n      <div\r\n        nz-row\r\n        [nzType]=\"'flex'\"\r\n        [nzJustify]=\"'center'\"\r\n        [nzAlign]=\"'middle'\"\r\n        class=\"bg-grey-darker py-sm text-center\"\r\n      >\r\n        <div nz-col [nzSpan]=\"16\">\r\n          <g2-mini-bar\r\n            height=\"35\"\r\n            color=\"#fff\"\r\n            borderWidth=\"3\"\r\n            [padding]=\"[36, 30, 30, 30]\"\r\n            [data]=\"data\"\r\n          ></g2-mini-bar>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"8\">\r\n          <div class=\"text-white\">+150</div>\r\n          <div class=\"text-grey\">From last month</div>\r\n        </div>\r\n      </div>\r\n      <div class=\"py-sm text-center bg-white text-grey\">\r\n        <div nz-row>\r\n          <div nz-col [nzSpan]=\"12\">\r\n            <div class=\"text-grey-dark\">Gross income</div>\r\n            <h4 class=\"h4 mb0\">12000</h4>\r\n          </div>\r\n          <div nz-col [nzSpan]=\"12\">\r\n            <div class=\"text-grey-dark\">Net income</div>\r\n            <h4 class=\"h4 mb0\">5100</h4>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzSm=\"12\" nzMd=\"8\" class=\"mb-md\">\r\n    <div nz-row [nzType]=\"'flex'\" [nzJustify]=\"'center'\" [nzAlign]=\"'middle'\" class=\"rounded-md bg-blue\">\r\n      <div nz-col nzSpan=\"16\">\r\n        <img class=\"img-fluid align-middle\" src=\"./assets/tmp/img/bg1.jpg\" alt=\"\" />\r\n      </div>\r\n      <div nz-col nzSpan=\"8\" class=\"text-white text-center\">\r\n        <h2 class=\"h1 text-white mb0\">11°</h2>\r\n        <div class=\"py-sm\">Cold</div>\r\n        <i class=\"fa fa-sun-o fa-2x\"></i>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div nz-row nzGutter=\"16\">\r\n  <div nz-col nzXs=\"24\" nzMd=\"12\">\r\n    <nz-card [nzBordered]=\"false\" [nzCover]=\"coverTpl\">\r\n      <ng-template #coverTpl>\r\n        <img class=\"img\" src=\"//os.alipayobjects.com/rmsportal/GhjqstwSgxBXrZS.png\" />\r\n      </ng-template>\r\n      <h3>ANT DESIGN</h3>\r\n      <p class=\"text-grey\">A UI Design Language</p>\r\n      <ol class=\"list-styled text-lg pt-md\">\r\n        <li>Designed by experienced team, and showcase dozens of inspiring projects.</li>\r\n        <li>\r\n          Provide solutions for usual problems that may be encountered while developing enterprise-like complex UIs.\r\n        </li>\r\n        <li>Dozens of flexible and practical reusable components that increase your productivity.</li>\r\n      </ol>\r\n      <p class=\"pt-md mb0\">\r\n        <a class=\"text-grey\" href=\"//ng.ant.design\" target=\"_blank\">View Site...</a>\r\n      </p>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzMd=\"12\">\r\n    <nz-card [nzTitle]=\"nzTitle\" class=\"ant-card__body-nopadding\" [nzTitle]=\"nzTitle\">\r\n      <ng-template #nzTitle>\r\n        Recent Posts\r\n        <small class=\"text-sm font-weight-normal\">Venenatis portauam Inceptos ameteiam</small>\r\n      </ng-template>\r\n      <div\r\n        nz-row\r\n        [nzType]=\"'flex'\"\r\n        [nzJustify]=\"'center'\"\r\n        [nzAlign]=\"'middle'\"\r\n        class=\"py-sm bg-grey-lighter-h point\"\r\n        *ngFor=\"let item of todoData\"\r\n      >\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <nz-avatar [nzSrc]=\"'./assets/tmp/img/' + item.avatar + '.png'\"></nz-avatar>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"20\">\r\n          <strong>{{ item.name }}</strong>\r\n          <div>{{ item.content }}</div>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n  <div nz-col nzXs=\"24\" nzMd=\"12\">\r\n    <nz-card nzTitle=\"Todo lists\" class=\"ant-card__body-nopadding\">\r\n      <div\r\n        nz-row\r\n        [nzType]=\"'flex'\"\r\n        [nzJustify]=\"'center'\"\r\n        [nzAlign]=\"'middle'\"\r\n        class=\"py-sm bg-grey-lighter-h point\"\r\n        *ngFor=\"let item of todoData\"\r\n      >\r\n        <div nz-col [nzSpan]=\"4\" class=\"text-center\">\r\n          <nz-avatar [nzSrc]=\"'./assets/tmp/img/' + item.avatar + '.png'\"></nz-avatar>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"18\">\r\n          <strong>{{ item.name }}</strong>\r\n          <div [class.text-deleted]=\"item.completed\">{{ item.content }}</div>\r\n        </div>\r\n        <div nz-col [nzSpan]=\"2\" class=\"text-right pr-md\">\r\n          <i\r\n            nz-dropdown\r\n            [nzDropdownMenu]=\"menuTpl\"\r\n            nzPlacement=\"topRight\"\r\n            nz-icon\r\n            nzType=\"ellipsis\"\r\n            class=\"rotate-90\"\r\n          ></i>\r\n          <nz-dropdown-menu #menuTpl=\"nzDropdownMenu\">\r\n            <ul nz-menu>\r\n              <li nz-menu-item *ngIf=\"item.completed\" (click)=\"item.completed = false\">Active</li>\r\n              <li nz-menu-item *ngIf=\"!item.completed\" (click)=\"item.completed = true\">Completed</li>\r\n              <li nz-menu-item (click)=\"todoData.splice(todoData.indexOf(item), 1)\">Delted</li>\r\n            </ul>\r\n          </nz-dropdown-menu>\r\n        </div>\r\n      </div>\r\n    </nz-card>\r\n  </div>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./src/app/routes/widgets/widgets-routing.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/routes/widgets/widgets-routing.module.ts ***!
    \**********************************************************/

  /*! exports provided: WidgetsRoutingModule */

  /***/
  function srcAppRoutesWidgetsWidgetsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WidgetsRoutingModule", function () {
      return WidgetsRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _widgets_widgets_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./widgets/widgets.component */
    "./src/app/routes/widgets/widgets/widgets.component.ts");

    var routes = [{
      path: '',
      component: _widgets_widgets_component__WEBPACK_IMPORTED_MODULE_3__["WidgetsComponent"]
    }];

    var WidgetsRoutingModule = function WidgetsRoutingModule() {
      _classCallCheck(this, WidgetsRoutingModule);
    };

    WidgetsRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], WidgetsRoutingModule);
    /***/
  },

  /***/
  "./src/app/routes/widgets/widgets.module.ts":
  /*!**************************************************!*\
    !*** ./src/app/routes/widgets/widgets.module.ts ***!
    \**************************************************/

  /*! exports provided: WidgetsModule */

  /***/
  function srcAppRoutesWidgetsWidgetsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WidgetsModule", function () {
      return WidgetsModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _shared__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @shared */
    "./src/app/shared/index.ts");
    /* harmony import */


    var _widgets_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./widgets-routing.module */
    "./src/app/routes/widgets/widgets-routing.module.ts");
    /* harmony import */


    var _widgets_widgets_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./widgets/widgets.component */
    "./src/app/routes/widgets/widgets/widgets.component.ts");

    var COMPONENTS = [_widgets_widgets_component__WEBPACK_IMPORTED_MODULE_4__["WidgetsComponent"]];
    var COMPONENTS_NOROUNT = [];

    var WidgetsModule = function WidgetsModule() {
      _classCallCheck(this, WidgetsModule);
    };

    WidgetsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_shared__WEBPACK_IMPORTED_MODULE_2__["SharedModule"], _widgets_routing_module__WEBPACK_IMPORTED_MODULE_3__["WidgetsRoutingModule"]],
      declarations: [].concat(COMPONENTS, COMPONENTS_NOROUNT),
      entryComponents: COMPONENTS_NOROUNT
    })], WidgetsModule);
    /***/
  },

  /***/
  "./src/app/routes/widgets/widgets/widgets.component.less":
  /*!***************************************************************!*\
    !*** ./src/app/routes/widgets/widgets/widgets.component.less ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRoutesWidgetsWidgetsWidgetsComponentLess(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* stylelint-disable at-rule-empty-line-before,at-rule-name-space-after,at-rule-no-unknown */\n/* stylelint-disable no-duplicate-selectors */\n/* stylelint-disable */\n/* stylelint-disable declaration-bang-space-before,no-duplicate-selectors,string-no-newline */\n:host ::ng-deep .ant-carousel .slick-dots {\n  bottom: -10px;\n}\n:host ::ng-deep .ant-carousel .slick-dots button {\n  background: #000000;\n}\n:host ::ng-deep .ant-carousel .slick-dots .slick-active button {\n  background: #1890ff;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcm91dGVzL3dpZGdldHMvd2lkZ2V0cy93aWRnZXRzLmNvbXBvbmVudC5sZXNzIiwic3JjL2FwcC9yb3V0ZXMvd2lkZ2V0cy93aWRnZXRzL0Q6L015UHJvamVjdC/mr5XkuJrorr7orqHpobnnm64vd2ViL3RlYW11cC1zeXN0ZW0vc3JjL2FwcC9yb3V0ZXMvd2lkZ2V0cy93aWRnZXRzL3dpZGdldHMuY29tcG9uZW50Lmxlc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsNEZBQTRGO0FBQzVGLDZDQUE2QztBQUM3QyxzQkFBc0I7QUFDdEIsNkZBQTZGO0FDRjdGO0VBR00sYUFBQTtBREVOO0FDTEE7RUFLUSxtQkFBQTtBREdSO0FDUkE7RUFRUSxtQkFBQTtBREdSIiwiZmlsZSI6InNyYy9hcHAvcm91dGVzL3dpZGdldHMvd2lkZ2V0cy93aWRnZXRzLmNvbXBvbmVudC5sZXNzIiwic291cmNlc0NvbnRlbnQiOlsiLyogc3R5bGVsaW50LWRpc2FibGUgYXQtcnVsZS1lbXB0eS1saW5lLWJlZm9yZSxhdC1ydWxlLW5hbWUtc3BhY2UtYWZ0ZXIsYXQtcnVsZS1uby11bmtub3duICovXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSBuby1kdXBsaWNhdGUtc2VsZWN0b3JzICovXG4vKiBzdHlsZWxpbnQtZGlzYWJsZSAqL1xuLyogc3R5bGVsaW50LWRpc2FibGUgZGVjbGFyYXRpb24tYmFuZy1zcGFjZS1iZWZvcmUsbm8tZHVwbGljYXRlLXNlbGVjdG9ycyxzdHJpbmctbm8tbmV3bGluZSAqL1xuOmhvc3QgOjpuZy1kZWVwIC5hbnQtY2Fyb3VzZWwgLnNsaWNrLWRvdHMge1xuICBib3R0b206IC0xMHB4O1xufVxuOmhvc3QgOjpuZy1kZWVwIC5hbnQtY2Fyb3VzZWwgLnNsaWNrLWRvdHMgYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogIzAwMDAwMDtcbn1cbjpob3N0IDo6bmctZGVlcCAuYW50LWNhcm91c2VsIC5zbGljay1kb3RzIC5zbGljay1hY3RpdmUgYnV0dG9uIHtcbiAgYmFja2dyb3VuZDogIzE4OTBmZjtcbn1cbiIsIkBpbXBvcnQgJ35AZGVsb24vdGhlbWUvc3R5bGVzL2RlZmF1bHQnO1xuOmhvc3QgOjpuZy1kZWVwIHtcbiAgLmFudC1jYXJvdXNlbCB7XG4gICAgLnNsaWNrLWRvdHMge1xuICAgICAgYm90dG9tOiAtMTBweDtcbiAgICAgIGJ1dHRvbiB7XG4gICAgICAgIGJhY2tncm91bmQ6IEBncmV5LTEwO1xuICAgICAgfVxuICAgICAgLnNsaWNrLWFjdGl2ZSBidXR0b24ge1xuICAgICAgICBiYWNrZ3JvdW5kOiBAcHJpbWFyeS1jb2xvcjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ== */";
    /***/
  },

  /***/
  "./src/app/routes/widgets/widgets/widgets.component.ts":
  /*!*************************************************************!*\
    !*** ./src/app/routes/widgets/widgets/widgets.component.ts ***!
    \*************************************************************/

  /*! exports provided: WidgetsComponent */

  /***/
  function srcAppRoutesWidgetsWidgetsWidgetsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WidgetsComponent", function () {
      return WidgetsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ng-zorro-antd */
    "./node_modules/ng-zorro-antd/fesm2015/ng-zorro-antd.js");
    /* harmony import */


    var _delon_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @delon/theme */
    "./node_modules/@delon/theme/fesm2015/theme.js");

    var WidgetsComponent = /*#__PURE__*/function () {
      function WidgetsComponent(msg, http, cdr) {
        _classCallCheck(this, WidgetsComponent);

        this.msg = msg;
        this.http = http;
        this.cdr = cdr;
        this.data = [];
        this.smallData = [];
        this.todoData = [{
          completed: true,
          avatar: '1',
          name: '苏先生',
          content: "\u8BF7\u544A\u8BC9\u6211\uFF0C\u6211\u5E94\u8BE5\u8BF4\u70B9\u4EC0\u4E48\u597D\uFF1F"
        }, {
          completed: false,
          avatar: '2',
          name: 'はなさき',
          content: "\u30CF\u30EB\u30AB\u30BD\u30E9\u30C8\u30AD\u30D8\u30C0\u30C4\u30D2\u30AB\u30EA"
        }, {
          completed: false,
          avatar: '3',
          name: 'cipchk',
          content: "this world was never meant for one as beautiful as you."
        }, {
          completed: false,
          avatar: '4',
          name: 'Kent',
          content: "my heart is beating with hers"
        }, {
          completed: false,
          avatar: '5',
          name: 'Are you',
          content: "They always said that I love beautiful girl than my friends"
        }, {
          completed: false,
          avatar: '6',
          name: 'Forever',
          content: "Walking through green fields \uFF0Csunshine in my eyes."
        }];
        this.like = false;
        this.dislike = false;
      }

      _createClass(WidgetsComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.http.get('/chart/visit').subscribe(function (res) {
            _this.data = res;
            _this.smallData = res.slice(0, 6);

            _this.cdr.detectChanges();
          });
        }
      }]);

      return WidgetsComponent;
    }();

    WidgetsComponent.ctorParameters = function () {
      return [{
        type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"]
      }, {
        type: _delon_theme__WEBPACK_IMPORTED_MODULE_3__["_HttpClient"]
      }, {
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]
      }];
    };

    WidgetsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-widgets',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./widgets.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/routes/widgets/widgets/widgets.component.html"))["default"],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectionStrategy"].OnPush,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./widgets.component.less */
      "./src/app/routes/widgets/widgets/widgets.component.less"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"], _delon_theme__WEBPACK_IMPORTED_MODULE_3__["_HttpClient"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]])], WidgetsComponent);
    /***/
  }
}]);
//# sourceMappingURL=widgets-widgets-module-es5.js.map